// This is an Application File (Represent Entire Application)
const express = require('express');
const songOperations = require('./db/song-operations');
const app = express(); 
const cors = require('cors');
// Allow CORS

// Server Will take a request from the client and then add a new song in the database.

// app start on port no 1234, so it listen the client request on 1234 port no
app.use(cors());
app.use(express.json());
app.post('/add-song', async (request, response)=>{
    console.log('Add New Song Call ', request.body);
    const jsonData = request.body;
    try{
    const result = await songOperations.addSong(jsonData);
    response.send('Song Added ');
    }
    catch(err){
        response.send('Song Can not added due to some DB Error ');
        console.log('Error During Add Song ', err);
    }
});

app.get('/get-songs', async (request, response)=>{
    try{
    const songs = await songOperations.readAllSong();
    response.json({songs:songs});
    }
    catch(err){
        response.json({error:'E',message:'Unable to Read Songs'});
        console.log('Read Song Error ', err);

    }
});

app.listen(1234,err=>{
    if(err){
        console.log('Server Error..... ', err);
    }
    else{
        console.log("######Server Started............");
    }
})