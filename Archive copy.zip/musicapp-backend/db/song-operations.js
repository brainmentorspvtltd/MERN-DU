// CRUD Operations Perform
const SongModel = require('./song-schema');
const songOperations = {
    async addSong(songObject){
            return await SongModel.create(songObject);
    } ,
    async readAllSong(){
        return await SongModel.find({});
    } ,
    findSongByArtistName(){

    },
    removeSong(){

    },
    updateSong(){

    } 
}
module.exports = songOperations;

// const songObject = {artistName:'Daler Mehndi' , trackName:'Abcd',
//  image:' -amazon.com/images/M/MV5BNzAzNjc5MmItMTEyMC00M2I2LWI2ZGEtODA2NjM1NzU2NWFkXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_.jpg', 
//  audio:'https://github.com/brainmentorspvtltd/MERN-DU/blob/main/songs/b.m4a?raw=true'};
// songOperations.addSong(songObject);
// console.log('Added....');