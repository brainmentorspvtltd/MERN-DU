// This file is used to connect to the DataBase (Mongo Atlas)
const DB_URL  = "mongodb+srv://amit:amit123@musicdb.vfdbr.mongodb.net/musicdb?retryWrites=true&w=majority";
const mongoose = require('mongoose');
mongoose.connect(DB_URL, err=>{
    if(err){
        console.log('Connection Error ',err);
    }
    else{
        console.log('Connection Created..... ');
    }
});
module.exports = mongoose;