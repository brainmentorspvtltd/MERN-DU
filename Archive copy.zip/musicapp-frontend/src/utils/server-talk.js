export async function talkToITunesServer(singerName='sonunigam'){
    // Waiting for the response (await) 
    // if we specify await so we need to mark the method as async
    const URL = `https://itunes.apple.com/search?term=${singerName}&limit=50`;
    const response = await fetch(URL);
    const json = await response.json();
    return json;
    // const promise = fetch('https://itunes.apple.com/search?term=sonunigam&limit=10');
    // console.log(promise);
    // promise.then(response=>{
    //     console.log('Response', response);
    //     response.json().then(data=>{
    //             console.log('Data is ',data);
    //     }).catch(err=>{
    //         console.log('INvalid JSON ', err);
    //     });
    // }).catch(err=>{
    //     console.log('Error ',err);
    // });
}

export async function talkToBackEndServer(){
    const URL = 'http://localhost:1234/get-songs';
    const response = await fetch(URL);
    const json = await response.json();
    return json;
}