import {useRef, useState} from 'react';
export const AddNewSong =  ()=>{
    const artistNameInput = useRef();
    const trackNameInput = useRef();
    const imageInput = useRef();
    const audioInput = useRef();
    const [message, setMessage] = useState('');
    const addSong = async ()=>{
        const song = {
            artistName:artistNameInput.current.value,
            trackName:trackNameInput.current.value,
            image:imageInput.current.value,
            audio:audioInput.current.value
        }
        console.log('Req send ', song);
        // Send this data to the BackEnd
        try{
        const response = await fetch('http://localhost:1234/add-song',{
            url:'http://localhost:1234/add-song',
            method:'post',body:JSON.stringify(song),headers:{'content-type':'application/json'}
        });
        const text = await response.text();
        console.log('Response rec ', text);
        setMessage(text);
    }
    catch(err){
        setMessage('Error in Add ');
        console.log(err);
    }
    }
    return (
        <div>
            <p>{message}</p>
            <input ref={artistNameInput} type='text' placeholder='Type Artist Name'/>
            <br/>
            <input ref={trackNameInput} type='text' placeholder='Type Track Name'/>
            <br/>
            <input ref={imageInput} type='text' placeholder='Type Image URL'/>
            <br/>
            <input ref={audioInput} type='text' placeholder='Type Audio URL'/>
            <br/>
            <button onClick = {addSong}>Add New Song</button>
        </div>
    );
}