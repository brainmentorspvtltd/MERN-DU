export const Song = ({song})=>{
    const mystyle = {
        width:'100px',
        height:'100px'
    };
    return (<div>
        {/* <img src={song.artworkUrl100}/> */}
        <img style={mystyle} src={song.image}/>
        <br/>
        <label>{song.artistName}</label>
        <br/>
        <label>{song.trackName}</label>
        <br/>
        <audio controls preload="none" key={song.previewUrl} >
                <source src={song.audio} type="audio/mpeg"></source>
                <source src={song.audio} type="audio/ogg"></source>
                <source src={song.audio} type="audio/wav"></source>
        </audio>
        {/* <audio controls preload="none" key={song.previewUrl} >
                <source src={song.previewUrl} type="audio/mpeg"></source>
                <source src={song.previewUrl} type="audio/ogg"></source>
                <source src={song.previewUrl} type="audio/wav"></source>
        </audio> */}
        <hr/>
    </div>)
}