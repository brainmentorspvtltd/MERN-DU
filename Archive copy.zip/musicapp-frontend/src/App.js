// Functional Based Component (Arrow Function - ES6 (2015))
import {useEffect, useState, useRef} from 'react';
import { AddNewSong } from './components/AddNewSong';

import { Songs } from './components/Songs';
import { talkToBackEndServer, talkToITunesServer } from "./utils/server-talk"

// App is a Component (Small Unit Presentation )
export const App =  ()=>{
  const searchBox = useRef();

  const getSingerName = async ()=>{
    const singerName = searchBox.current.value; // Get the Singer Name from the TextBox and store in singerName constant
    console.log('Singer Name is ', singerName);
    //const json = await talkToITunesServer(singerName); // Calling ITunes API
    // Calling BackEnd Server
    const json = await talkToBackEndServer();
    console.log(singerName , ' Singer JSON is ' ,  json);
      
    //setSongs(json.results);
    setSongs(json.songs);
  }

 // var arr = []; // this is a song array and initally it is empty
  const [songs , setSongs ] = useState([]);
  // useEffect (Hook) will be call when the component did loaded...
    useEffect(async ()=>{
      //const json = await talkToITunesServer();
      const json = await talkToBackEndServer();  
      setSongs(json.songs);
      //setSongs(json.results); // State Change so View will be change
      //console.log(':::::JSON Rec Store in Array ', songs);
    },[]);
      
    
    
   
   // Talk to ITunes API 
  // this function is returning JSX
  //return (<h1 className='alert-danger text-center'>Music App-2022</h1>) 
    return (<div className='container'>
      <AddNewSong/>
      <br/>
      <input ref={searchBox} type='text' placeholder="Type Singer Name to Search" className='form-control'/>
      <button onClick={getSingerName} className = 'btn btn-primary'>Search it</button>
      <br/>
      <hr/>
      <br/>
      <Songs listofsongs = {songs}/></div>)
}