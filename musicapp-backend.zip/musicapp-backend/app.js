// This is an Application File (Represent Entire Application)
const express = require('express');
const app = express(); 
// app start on port no 1234, so it listen the client request on 1234 port no
app.listen(1234,err=>{
    if(err){
        console.log('Server Error..... ', err);
    }
    else{
        console.log("######Server Started............");
    }
})