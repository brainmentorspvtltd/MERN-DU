// {artistName:’Sonu Nigam’ , trackName:’Kal ho na ho’, image:’’, audio:’’} - Structure of Schema
const { SchemaTypes } = require('./connection');
const mongoose = require('./connection');
const Schema  = mongoose.Schema; // Can Create a Schema
const songSchema = new Schema({
    artistName : SchemaTypes.String,
    trackName: SchemaTypes.String,
    image : SchemaTypes.String, // IMAGE URL 
    audio: SchemaTypes.String // AUDIO URL
});
const SongModel = mongoose.model('songs', songSchema); // songs is become a collection in Mongo Atlas
module.exports = SongModel;
