// CRUD Operations Perform
const SongModel = require('./song-schema');
const songOperations = {
    async addSong(songObject){
            return await SongModel.create(songObject);
    } ,
    readAllSong(){

    } ,
    findSongByArtistName(){

    },
    removeSong(){

    },
    updateSong(){

    } 
}

const songObject = {artistName:'Sonu Nigam' , trackName:'Kal ho na ho', image:'https://images.indianexpress.com/2021/07/sonu-nigam-1200-1.jpg', audio:'https://github.com/brainmentorspvtltd/MERN-DU/blob/main/songs/a.m4a?raw=true'};
songOperations.addSong(songObject);
console.log('Added....');