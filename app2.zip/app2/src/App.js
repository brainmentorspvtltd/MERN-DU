// Functional Based Component (Arrow Function - ES6 (2015))
import {useEffect, useState} from 'react';

import { Songs } from './components/Songs';
import { talkToITunesServer } from "./utils/server-talk"

// App is a Component (Small Unit Presentation )
export const App =  ()=>{
  
 // var arr = []; // this is a song array and initally it is empty
  const [songs , setSongs ] = useState([]);
  // useEffect (Hook) will be call when the component did loaded...
    useEffect(async ()=>{
      const json = await talkToITunesServer();
      
      setSongs(json.results); // State Change so View will be change
      //console.log(':::::JSON Rec Store in Array ', songs);
    },[]);
      
    
    
   
   // Talk to ITunes API 
  // this function is returning JSX
  //return (<h1 className='alert-danger text-center'>Music App-2022</h1>) 
    return (<div>
      <input type='text' placeholder="Type Singer Name to Search" className='form-control'/>
      <button className = 'btn btn-primary'>Search it</button>
      <br/>
      <hr/>
      <br/>
      <Songs listofsongs = {songs}/></div>)
}