import {Song} from './Song';
export const Songs = ({listofsongs})=>{
    console.log('Songs Rec in Songs Component ', listofsongs);
    return (<div>{listofsongs.map((singleSong, index)=><Song song={singleSong} key={index}/>)}</div>)
}