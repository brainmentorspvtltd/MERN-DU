export const Song = ({song})=>{
    return (<div>
        <img src={song.artworkUrl100}/>
        <br/>
        <label>{song.artistName}</label>
        <br/>
        <label>{song.trackName}</label>
        <br/>
        <audio controls>
                <source src={song.previewUrl} type="audio/mpeg"></source>
                <source src={song.previewUrl} type="audio/ogg"></source>
                <source src={song.previewUrl} type="audio/wav"></source>
        </audio>
        <hr/>
    </div>)
}