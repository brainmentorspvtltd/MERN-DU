import {App} from './App';
import ReactDOM from 'react-dom';
// document  - HTML Page
var div = document.getElementById('root'); // Lookup Div that id is root
ReactDOM.render(<App/>, div); // Place App inside a div tag