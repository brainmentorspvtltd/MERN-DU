// Functional Based Component (Arrow Function - ES6 (2015))

import { talkToITunesServer } from "./utils/server-talk"

// App is a Component (Small Unit Presentation )
export const App = ()=>{
  talkToITunesServer(); // Talk to ITunes API - Suggest Hooks
  // this function is returning JSX
  return (<h1 className='alert-danger text-center'>Music App-2022</h1>) 
}