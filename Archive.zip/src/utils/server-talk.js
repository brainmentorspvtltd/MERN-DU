export function talkToITunesServer(){
    const promise = fetch('https://itunes.apple.com/search?term=sonu nigam&limit=10');
    console.log(promise);
    promise.then(response=>{
        console.log('Response', response);
        response.json().then(data=>{
                console.log('Data is ',data);
        }).catch(err=>{
            console.log('INvalid JSON ', err);
        });
    }).catch(err=>{
        console.log('Error ',err);
    });
}